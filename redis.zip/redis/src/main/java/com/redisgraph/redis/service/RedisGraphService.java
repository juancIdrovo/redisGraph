package com.redisgraph.redis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisAccessor;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@Service
public class RedisGraphService {

    @Autowired
    private RedisTemplate<String, byte[]> redisTemplate;

    private final static Logger LOGGER = Logger.getLogger(RedisGraphService.class.getName());

    public List<List<String>> executeQuery(String query) {
        List<List<String>> result = new ArrayList<>();
        try {
            byte[] rawResult = (byte[]) redisTemplate.execute(new RedisCallback<byte[]>() {
                @Override
                public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
                    return (byte[]) connection.execute("GRAPH.QUERY", "social".getBytes(StandardCharsets.UTF_8), query.getBytes(StandardCharsets.UTF_8));
                }
            });
            if (rawResult!= null) {
                String rawString = new String(rawResult, StandardCharsets.UTF_8);
                LOGGER.info("Raw Query Result: " + rawString);
                result = parseRawResult(rawString);
            }
        } catch (Exception e) {
        	LOGGER.severe("Error executing query: " + e.getMessage());
        }
        return result;
    }

    private List<List<String>> parseRawResult(String rawResult) {
        LOGGER.info("Parsing raw result: " + rawResult);
        List<List<String>> result = new ArrayList<>();
        String[] lines = rawResult.split("\n");

        boolean isHeader = true;
        for (String line : lines) {
            LOGGER.info("Processing line: " + line);
            if (line.trim().isEmpty() || line.startsWith("Query internal execution time")) {
                continue;
            }
            if (isHeader) {
                isHeader = false;
                continue;
            }
            String[] columns = line.split(",");
            List<String> row = new ArrayList<>();
            for (String column : columns) {
                row.add(column.trim());
            }
            result.add(row);
        }
        LOGGER.info("Parsed result: " + result);
        return result;
    }
    public void createDirectorAndMovie() {
        LOGGER.info("Creating Director and Movie...");
        executeQuery("CREATE (:Director {name: 'Denis Villeneuve', age: 53})");
        executeQuery("CREATE (:Movie {title: 'Dune', release_year: 2021})");
        executeQuery("MATCH (d:Director {name: 'Denis Villeneuve'}), (m:Movie {title: 'Dune'}) CREATE (d)-[:DIRECTED]->(m)");
        LOGGER.info("Director and Movie created successfully.");
    }


    public List<List<String>> getDirectorsAndMovies() {
        List<List<String>> result = executeQuery("MATCH (d:Director)-[:DIRECTED]->(m:Movie) RETURN d.name, m.title");
        LOGGER.info("Query result: " + result);
        return result;
    }
}
