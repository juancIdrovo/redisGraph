package com.redisgraph.redis.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.redisgraph.redis.service.RedisGraphService;

import java.util.List;

@RestController
@RequestMapping("/redisgraph")
public class RedisGraphController {

    @Autowired
    private RedisGraphService redisGraphService;

    @PostMapping("/create")
    public String createDirectorAndMovie() {
        redisGraphService.createDirectorAndMovie();
        return "Director and Movie created";
    }

    @GetMapping("/directors-movies")
    public List<List<String>> getDirectorsAndMovies() {
        return redisGraphService.getDirectorsAndMovies();
    }
}
